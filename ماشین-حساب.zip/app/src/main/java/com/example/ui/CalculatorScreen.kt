package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculator.CalculatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showHistorySheet by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissSnackbar()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "ماشین حساب",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                        )
                    }
                },
                actions = {
                    // Persian / English digits toggle
                    FilterChip(
                        selected = uiState.usePersianDigits,
                        onClick = { viewModel.onTogglePersianDigits() },
                        label = {
                            Text(
                                text = if (uiState.usePersianDigits) "۱۲۳" else "123",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier
                            .testTag("btn_toggle_persian")
                            .padding(end = 4.dp)
                    )

                    // Scientific functions toggle
                    IconButton(
                        onClick = { viewModel.onToggleScientific() },
                        modifier = Modifier.testTag("btn_toggle_scientific")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Functions,
                            contentDescription = "توابع ریاضی",
                            tint = if (uiState.isScientificOpen) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // History sheet toggle
                    IconButton(
                        onClick = { showHistorySheet = true },
                        modifier = Modifier.testTag("btn_history")
                    ) {
                        if (uiState.history.isNotEmpty()) {
                            BadgedBox(
                                badge = {
                                    Badge {
                                        val count = if (uiState.usePersianDigits)
                                            com.example.calculator.CalculatorEngine.toPersianDigits(uiState.history.size.toString())
                                        else uiState.history.size.toString()
                                        Text(count)
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = "تاریخچه"
                                )
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "تاریخچه"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWideScreen = maxWidth > 600.dp

            if (isWideScreen) {
                // Wide Screen / Tablet Landscape Layout
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Left: Display & History
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        CalculatorDisplay(
                            expression = uiState.expression,
                            previewResult = uiState.previewResult,
                            evaluatedResult = uiState.evaluatedResult,
                            errorMessage = uiState.errorMessage,
                            usePersianDigits = uiState.usePersianDigits,
                            onResultClick = {
                                val toCopy = uiState.evaluatedResult ?: uiState.previewResult
                                toCopy?.let { viewModel.copyToClipboard(it) }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Right: Keypad
                    Column(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight()
                    ) {
                        KeypadLayout(
                            viewModel = viewModel,
                            uiState = uiState,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            } else {
                // Standard Mobile Portrait Layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Display Area
                    CalculatorDisplay(
                        expression = uiState.expression,
                        previewResult = uiState.previewResult,
                        evaluatedResult = uiState.evaluatedResult,
                        errorMessage = uiState.errorMessage,
                        usePersianDigits = uiState.usePersianDigits,
                        onResultClick = {
                            val toCopy = uiState.evaluatedResult ?: uiState.previewResult
                            toCopy?.let { viewModel.copyToClipboard(it) }
                        },
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Keypad Area
                    KeypadLayout(
                        viewModel = viewModel,
                        uiState = uiState,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }

    if (showHistorySheet) {
        HistorySheet(
            history = uiState.history,
            usePersianDigits = uiState.usePersianDigits,
            onDismiss = { showHistorySheet = false },
            onSelectExpression = { item ->
                viewModel.onSelectHistoryItem(item, useResultOnly = false)
            },
            onSelectResult = { item ->
                viewModel.onSelectHistoryItem(item, useResultOnly = true)
            },
            onClearHistory = {
                viewModel.onClearHistory()
            },
            onCopy = { result ->
                viewModel.copyToClipboard(result)
            }
        )
    }
}

@Composable
private fun KeypadLayout(
    viewModel: CalculatorViewModel,
    uiState: com.example.calculator.CalculatorUiState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Optional Scientific Bar
        AnimatedVisibility(
            visible = uiState.isScientificOpen,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalculatorButton(
                    text = "(",
                    buttonType = ButtonType.SCIENTIFIC,
                    usePersianDigits = uiState.usePersianDigits,
                    modifier = Modifier.weight(1f)
                ) { viewModel.onDigit("(") }

                CalculatorButton(
                    text = ")",
                    buttonType = ButtonType.SCIENTIFIC,
                    usePersianDigits = uiState.usePersianDigits,
                    modifier = Modifier.weight(1f)
                ) { viewModel.onDigit(")") }

                CalculatorButton(
                    text = "%",
                    buttonType = ButtonType.SCIENTIFIC,
                    usePersianDigits = uiState.usePersianDigits,
                    modifier = Modifier.weight(1f)
                ) { viewModel.onPercent() }

                CalculatorButton(
                    text = "^",
                    buttonType = ButtonType.SCIENTIFIC,
                    usePersianDigits = uiState.usePersianDigits,
                    modifier = Modifier.weight(1f)
                ) { viewModel.onOperator("^") }

                CalculatorButton(
                    text = "√",
                    buttonType = ButtonType.SCIENTIFIC,
                    usePersianDigits = uiState.usePersianDigits,
                    modifier = Modifier.weight(1f)
                ) { viewModel.onSquareRoot() }
            }
        }

        // Row 1: AC, ⌫, ±, ÷
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            CalculatorButton(
                text = "AC",
                buttonType = ButtonType.ACTION,
                testTag = "clear",
                modifier = Modifier.weight(1f)
            ) { viewModel.onClear() }

            CalculatorButton(
                text = "⌫",
                buttonType = ButtonType.ACTION,
                icon = Icons.AutoMirrored.Filled.Backspace,
                testTag = "backspace",
                modifier = Modifier.weight(1f)
            ) { viewModel.onBackspace() }

            CalculatorButton(
                text = "±",
                buttonType = ButtonType.OPERATOR,
                testTag = "plus_minus",
                modifier = Modifier.weight(1f)
            ) { viewModel.onToggleSign() }

            CalculatorButton(
                text = "÷",
                buttonType = ButtonType.OPERATOR,
                testTag = "divide",
                modifier = Modifier.weight(1f)
            ) { viewModel.onOperator("÷") }
        }

        // Row 2: 7, 8, 9, ×
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            CalculatorButton(
                text = "7",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("7") }

            CalculatorButton(
                text = "8",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("8") }

            CalculatorButton(
                text = "9",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("9") }

            CalculatorButton(
                text = "×",
                buttonType = ButtonType.OPERATOR,
                testTag = "multiply",
                modifier = Modifier.weight(1f)
            ) { viewModel.onOperator("×") }
        }

        // Row 3: 4, 5, 6, −
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            CalculatorButton(
                text = "4",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("4") }

            CalculatorButton(
                text = "5",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("5") }

            CalculatorButton(
                text = "6",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("6") }

            CalculatorButton(
                text = "−",
                buttonType = ButtonType.OPERATOR,
                testTag = "minus",
                modifier = Modifier.weight(1f)
            ) { viewModel.onOperator("-") }
        }

        // Row 4: 1, 2, 3, +
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            CalculatorButton(
                text = "1",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("1") }

            CalculatorButton(
                text = "2",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("2") }

            CalculatorButton(
                text = "3",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("3") }

            CalculatorButton(
                text = "+",
                buttonType = ButtonType.OPERATOR,
                testTag = "plus",
                modifier = Modifier.weight(1f)
            ) { viewModel.onOperator("+") }
        }

        // Row 5: 0, 00, ., =
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            CalculatorButton(
                text = "0",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDigit("0") }

            CalculatorButton(
                text = "00",
                buttonType = ButtonType.NUMBER,
                usePersianDigits = uiState.usePersianDigits,
                modifier = Modifier.weight(1f)
            ) { viewModel.onDoubleZero() }

            CalculatorButton(
                text = ".",
                buttonType = ButtonType.NUMBER,
                testTag = "decimal",
                modifier = Modifier.weight(1f)
            ) { viewModel.onDecimal() }

            CalculatorButton(
                text = "=",
                buttonType = ButtonType.EQUAL,
                testTag = "equals",
                modifier = Modifier.weight(1f)
            ) { viewModel.onCalculate() }
        }
    }
}
