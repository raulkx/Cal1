package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val CalcPrimaryLight = Color(0xFF0F6CBD)
val CalcOnPrimaryLight = Color(0xFFFFFFFF)
val CalcPrimaryContainerLight = Color(0xFFD6E4FF)
val CalcOnPrimaryContainerLight = Color(0xFF001B3E)

val CalcSecondaryLight = Color(0xFF4F5E7B)
val CalcOnSecondaryLight = Color(0xFFFFFFFF)
val CalcSecondaryContainerLight = Color(0xFFD9E2FF)
val CalcOnSecondaryContainerLight = Color(0xFF0A1B34)

val CalcTertiaryLight = Color(0xFFC04B00)
val CalcOnTertiaryLight = Color(0xFFFFFFFF)
val CalcTertiaryContainerLight = Color(0xFFFFDBCF)
val CalcOnTertiaryContainerLight = Color(0xFF381000)

val CalcBackgroundLight = Color(0xFFF8F9FD)
val CalcSurfaceLight = Color(0xFFFFFFFF)
val CalcSurfaceVariantLight = Color(0xFFE8EEF8)
val CalcOnSurfaceLight = Color(0xFF191C20)
val CalcOnSurfaceVariantLight = Color(0xFF43474F)

// Dark Theme Palette - Deep Sleek Dark
val CalcPrimaryDark = Color(0xFF9ECAFF)
val CalcOnPrimaryDark = Color(0xFF003258)
val CalcPrimaryContainerDark = Color(0xFF00497D)
val CalcOnPrimaryContainerDark = Color(0xFFD1E4FF)

val CalcSecondaryDark = Color(0xFFB7C7EA)
val CalcOnSecondaryDark = Color(0xFF21304C)
val CalcSecondaryContainerDark = Color(0xFF384663)
val CalcOnSecondaryContainerDark = Color(0xFFD8E3FF)

val CalcTertiaryDark = Color(0xFFFFB59D)
val CalcOnTertiaryDark = Color(0xFF5F1D00)
val CalcTertiaryContainerDark = Color(0xFF862D00)
val CalcOnTertiaryContainerDark = Color(0xFFFFDBCF)

val CalcBackgroundDark = Color(0xFF0E131F)
val CalcSurfaceDark = Color(0xFF161D2E)
val CalcSurfaceVariantDark = Color(0xFF222B3F)
val CalcOnSurfaceDark = Color(0xFFE1E2E8)
val CalcOnSurfaceVariantDark = Color(0xFFC3C7D2)

// Dedicated Key Colors
val CalcEqualLight = Color(0xFF0F6CBD)
val CalcEqualDark = Color(0xFF3B82F6)
val CalcOperatorLight = Color(0xFFE2EDFE)
val CalcOperatorDark = Color(0xFF1E2F4D)
val CalcActionLight = Color(0xFFFFEAE3)
val CalcActionDark = Color(0xFF3F2018)
val CalcActionTextLight = Color(0xFFB3261E)
val CalcActionTextDark = Color(0xFFFF897D)
