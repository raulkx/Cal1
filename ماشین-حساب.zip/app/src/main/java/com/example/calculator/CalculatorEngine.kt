package com.example.calculator

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.pow
import kotlin.math.sqrt

sealed class CalculationResult {
    data class Success(val value: BigDecimal, val formatted: String) : CalculationResult()
    data class Error(val message: String) : CalculationResult()
}

object CalculatorEngine {

    private val mathContext = MathContext(16, RoundingMode.HALF_UP)

    fun evaluate(rawExpression: String): CalculationResult {
        val sanitized = sanitize(rawExpression)
        if (sanitized.isEmpty()) {
            return CalculationResult.Error("عبارت خالی است")
        }

        return try {
            val parser = ExpressionParser(sanitized)
            val result = parser.parse()
            if (result.isNaN() || result.isInfinite()) {
                CalculationResult.Error("نتیجه نامعتبر است")
            } else {
                val bigDecimal = BigDecimal(result, mathContext).stripTrailingZeros()
                CalculationResult.Success(bigDecimal, formatNumber(bigDecimal))
            }
        } catch (e: ArithmeticException) {
            CalculationResult.Error(e.message ?: "خطای ریاضی")
        } catch (e: Exception) {
            CalculationResult.Error("خطا در عبارت")
        }
    }

    /**
     * Evaluates incomplete expressions for real-time live preview.
     * For instance: "5 + " previews "5", "(4 * 2" auto-closes to "(4 * 2)" and previews "8".
     */
    fun evaluatePreview(rawExpression: String): String? {
        var expr = sanitize(rawExpression)
        if (expr.isEmpty()) return null

        // Trim trailing operators
        while (expr.isNotEmpty() && isTrailingOperator(expr.last())) {
            expr = expr.dropLast(1)
        }
        if (expr.isEmpty()) return null

        // Auto-close open parentheses
        val openParen = expr.count { it == '(' }
        val closeParen = expr.count { it == ')' }
        if (openParen > closeParen) {
            expr += ")".repeat(openParen - closeParen)
        }

        return when (val result = evaluate(expr)) {
            is CalculationResult.Success -> result.formatted
            is CalculationResult.Error -> null
        }
    }

    private fun isTrailingOperator(char: Char): Boolean {
        return char in setOf('+', '-', '×', '÷', '*', '/', '^', '%', '(', '.')
    }

    private fun sanitize(expression: String): String {
        return expression
            .replace(" ", "")
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace(",", "")
    }

    fun formatNumber(number: BigDecimal): String {
        val symbols = DecimalFormatSymbols(Locale.US)
        val format = DecimalFormat("#,##0.##########", symbols)
        return format.format(number)
    }

    fun formatNumber(numberString: String): String {
        return try {
            val bd = BigDecimal(numberString.replace(",", ""))
            formatNumber(bd)
        } catch (e: Exception) {
            numberString
        }
    }

    /**
     * Converts standard Western digits (0-9) to Persian digits (۰-۹)
     */
    fun toPersianDigits(text: String): String {
        val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
        val sb = StringBuilder()
        for (ch in text) {
            if (ch in '0'..'9') {
                sb.append(persianDigits[ch - '0'])
            } else if (ch == '.') {
                sb.append('٫') // Persian decimal separator
            } else if (ch == ',') {
                sb.append('٬') // Persian thousands separator
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Converts Persian digits back to standard digits
     */
    fun fromPersianDigits(text: String): String {
        val sb = StringBuilder()
        for (ch in text) {
            when (ch) {
                '۰' -> sb.append('0')
                '۱' -> sb.append('1')
                '۲' -> sb.append('2')
                '۳' -> sb.append('3')
                '۴' -> sb.append('4')
                '۵' -> sb.append('5')
                '۶' -> sb.append('6')
                '۷' -> sb.append('7')
                '۸' -> sb.append('8')
                '۹' -> sb.append('9')
                '٫' -> sb.append('.')
                '٬' -> sb.append(',')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Recursive Descent Parser for expressions
     * Grammar:
     *   expression = term (('+' | '-') term)*
     *   term       = factor (('*' | '/' | '%') factor)*
     *   factor     = power ('^' factor)?
     *   power      = ('+' | '-') power | '√' power | primary ('%')*
     *   primary    = NUMBER | '(' expression ')'
     */
    private class ExpressionParser(private val src: String) {
        private var pos = 0

        fun parse(): Double {
            pos = 0
            val res = parseExpression()
            if (pos < src.length) {
                throw IllegalArgumentException("کاراکتر غیرمنتظره در موقعیت $pos")
            }
            return res
        }

        private fun parseExpression(): Double {
            var result = parseTerm()
            while (pos < src.length) {
                val op = src[pos]
                if (op == '+' || op == '-') {
                    pos++
                    val nextTerm = parseTerm()
                    result = if (op == '+') result + nextTerm else result - nextTerm
                } else {
                    break
                }
            }
            return result
        }

        private fun parseTerm(): Double {
            var result = parseFactor()
            while (pos < src.length) {
                val op = src[pos]
                if (op == '*' || op == '/' || op == '%') {
                    pos++
                    val nextFactor = parseFactor()
                    when (op) {
                        '*' -> result *= nextFactor
                        '/' -> {
                            if (nextFactor == 0.0) {
                                throw ArithmeticException("تقسیم بر صفر ممکن نیست")
                            }
                            result /= nextFactor
                        }
                        '%' -> {
                            // Modulo or percentage calculation
                            result %= nextFactor
                        }
                    }
                } else {
                    break
                }
            }
            return result
        }

        private fun parseFactor(): Double {
            val base = parseUnary()
            if (pos < src.length && src[pos] == '^') {
                pos++
                val exponent = parseFactor()
                return base.pow(exponent)
            }
            return base
        }

        private fun parseUnary(): Double {
            if (pos >= src.length) {
                throw IllegalArgumentException("پایان غیرمنتظره عبارت")
            }

            val ch = src[pos]
            if (ch == '+') {
                pos++
                return parseUnary()
            }
            if (ch == '-') {
                pos++
                return -parseUnary()
            }
            if (ch == '√') {
                pos++
                val value = parseUnary()
                if (value < 0) {
                    throw ArithmeticException("جذر عدد منفی تعریف نشده است")
                }
                return sqrt(value)
            }

            var value = parsePrimary()
            // Support postfix percent: e.g. 50% = 0.5
            while (pos < src.length && src[pos] == '%') {
                pos++
                value /= 100.0
            }
            return value
        }

        private fun parsePrimary(): Double {
            if (pos >= src.length) {
                throw IllegalArgumentException("پایان غیرمنتظره عبارت")
            }

            val ch = src[pos]
            if (ch == '(') {
                pos++
                val value = parseExpression()
                if (pos < src.length && src[pos] == ')') {
                    pos++
                } else {
                    throw IllegalArgumentException("پرانتز بسته نشده است")
                }
                return value
            }

            val start = pos
            if (ch.isDigit() || ch == '.') {
                var hasDot = ch == '.'
                pos++
                while (pos < src.length) {
                    val c = src[pos]
                    if (c.isDigit()) {
                        pos++
                    } else if (c == '.' && !hasDot) {
                        hasDot = true
                        pos++
                    } else {
                        break
                    }
                }
                val numStr = src.substring(start, pos)
                return numStr.toDoubleOrNull()
                    ?: throw IllegalArgumentException("عدد نامعتبر: $numStr")
            }

            throw IllegalArgumentException("کاراکتر نامعتبر: '$ch' در موقعیت $pos")
        }
    }
}
