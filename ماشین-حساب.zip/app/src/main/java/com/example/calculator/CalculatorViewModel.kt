package com.example.calculator

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HistoryItem(
    val id: Long = System.currentTimeMillis(),
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class CalculatorUiState(
    val expression: String = "",
    val previewResult: String? = null,
    val evaluatedResult: String? = null,
    val isCalculated: Boolean = false,
    val history: List<HistoryItem> = emptyList(),
    val usePersianDigits: Boolean = false,
    val isScientificOpen: Boolean = false,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    fun onDigit(digit: String) {
        _uiState.update { current ->
            val newExpr = if (current.isCalculated) {
                digit
            } else {
                if (current.expression == "0" && digit != ".") digit else current.expression + digit
            }
            val preview = CalculatorEngine.evaluatePreview(newExpr)
            current.copy(
                expression = newExpr,
                previewResult = preview,
                isCalculated = false,
                errorMessage = null
            )
        }
    }

    fun onDoubleZero() {
        _uiState.update { current ->
            if (current.isCalculated) {
                current.copy(expression = "0", previewResult = "0", isCalculated = false)
            } else if (current.expression.isNotEmpty() && !isLastCharOperator(current.expression)) {
                val newExpr = current.expression + "00"
                val preview = CalculatorEngine.evaluatePreview(newExpr)
                current.copy(
                    expression = newExpr,
                    previewResult = preview,
                    errorMessage = null
                )
            } else {
                current
            }
        }
    }

    fun onDecimal() {
        _uiState.update { current ->
            if (current.isCalculated) {
                val newExpr = "0."
                current.copy(
                    expression = newExpr,
                    previewResult = null,
                    isCalculated = false,
                    errorMessage = null
                )
            } else {
                val lastNumber = getLastNumberToken(current.expression)
                if (!lastNumber.contains(".")) {
                    val prefix = if (current.expression.isEmpty() || isLastCharOperator(current.expression)) "0." else "."
                    val newExpr = current.expression + prefix
                    current.copy(
                        expression = newExpr,
                        previewResult = CalculatorEngine.evaluatePreview(newExpr),
                        errorMessage = null
                    )
                } else {
                    current
                }
            }
        }
    }

    fun onOperator(op: String) {
        _uiState.update { current ->
            val baseExpr = if (current.isCalculated && current.evaluatedResult != null) {
                current.evaluatedResult.replace(",", "")
            } else {
                current.expression
            }

            if (baseExpr.isEmpty()) {
                if (op == "-") {
                    current.copy(expression = "-", isCalculated = false, errorMessage = null)
                } else {
                    current
                }
            } else {
                val lastChar = baseExpr.last()
                val newExpr = if (isOperator(lastChar.toString())) {
                    baseExpr.dropLast(1) + op
                } else {
                    baseExpr + op
                }
                current.copy(
                    expression = newExpr,
                    isCalculated = false,
                    previewResult = CalculatorEngine.evaluatePreview(newExpr),
                    errorMessage = null
                )
            }
        }
    }

    fun onSquareRoot() {
        _uiState.update { current ->
            val newExpr = if (current.isCalculated) {
                "√("
            } else {
                current.expression + "√("
            }
            current.copy(
                expression = newExpr,
                isCalculated = false,
                previewResult = CalculatorEngine.evaluatePreview(newExpr),
                errorMessage = null
            )
        }
    }

    fun onParenthesis() {
        _uiState.update { current ->
            val expr = current.expression
            val openCount = expr.count { it == '(' }
            val closeCount = expr.count { it == ')' }

            val shouldClose = openCount > closeCount && expr.isNotEmpty() &&
                    (expr.last().isDigit() || expr.last() == ')')

            val newExpr = if (shouldClose) {
                "$expr)"
            } else {
                if (expr.isNotEmpty() && (expr.last().isDigit() || expr.last() == ')')) {
                    "$expr×("
                } else {
                    "$expr("
                }
            }

            current.copy(
                expression = newExpr,
                isCalculated = false,
                previewResult = CalculatorEngine.evaluatePreview(newExpr),
                errorMessage = null
            )
        }
    }

    fun onPercent() {
        _uiState.update { current ->
            if (current.expression.isNotEmpty() && !isLastCharOperator(current.expression)) {
                val newExpr = current.expression + "%"
                current.copy(
                    expression = newExpr,
                    isCalculated = false,
                    previewResult = CalculatorEngine.evaluatePreview(newExpr),
                    errorMessage = null
                )
            } else {
                current
            }
        }
    }

    fun onToggleSign() {
        _uiState.update { current ->
            val expr = current.expression
            if (expr.isEmpty()) return@update current

            val lastNum = getLastNumberToken(expr)
            if (lastNum.isEmpty()) return@update current

            val beforeNum = expr.dropLast(lastNum.length)
            val newExpr = if (beforeNum.endsWith("(-")) {
                beforeNum.dropLast(2) + lastNum
            } else if (beforeNum.endsWith("-") && (beforeNum.length == 1 || isLastCharOperator(beforeNum.dropLast(1)))) {
                beforeNum.dropLast(1) + lastNum
            } else {
                beforeNum + "(-$lastNum)"
            }

            current.copy(
                expression = newExpr,
                previewResult = CalculatorEngine.evaluatePreview(newExpr),
                errorMessage = null
            )
        }
    }

    fun onBackspace() {
        _uiState.update { current ->
            if (current.isCalculated) {
                current.copy(expression = "", previewResult = null, evaluatedResult = null, isCalculated = false)
            } else if (current.expression.isNotEmpty()) {
                val newExpr = current.expression.dropLast(1)
                current.copy(
                    expression = newExpr,
                    previewResult = CalculatorEngine.evaluatePreview(newExpr),
                    errorMessage = null
                )
            } else {
                current
            }
        }
    }

    fun onClear() {
        _uiState.update { current ->
            current.copy(
                expression = "",
                previewResult = null,
                evaluatedResult = null,
                isCalculated = false,
                errorMessage = null
            )
        }
    }

    fun onCalculate() {
        val current = _uiState.value
        if (current.expression.isEmpty()) return

        when (val result = CalculatorEngine.evaluate(current.expression)) {
            is CalculationResult.Success -> {
                val newHistoryItem = HistoryItem(
                    expression = current.expression,
                    result = result.formatted
                )
                _uiState.update {
                    it.copy(
                        expression = current.expression,
                        evaluatedResult = result.formatted,
                        previewResult = null,
                        isCalculated = true,
                        errorMessage = null,
                        history = listOf(newHistoryItem) + it.history
                    )
                }
            }
            is CalculationResult.Error -> {
                _uiState.update {
                    it.copy(
                        errorMessage = result.message
                    )
                }
            }
        }
    }

    fun onTogglePersianDigits() {
        _uiState.update { it.copy(usePersianDigits = !it.usePersianDigits) }
    }

    fun onToggleScientific() {
        _uiState.update { it.copy(isScientificOpen = !it.isScientificOpen) }
    }

    fun onSelectHistoryItem(item: HistoryItem, useResultOnly: Boolean) {
        _uiState.update { current ->
            val expr = if (useResultOnly) item.result.replace(",", "") else item.expression
            current.copy(
                expression = expr,
                previewResult = CalculatorEngine.evaluatePreview(expr),
                isCalculated = useResultOnly,
                evaluatedResult = if (useResultOnly) item.result else null,
                errorMessage = null
            )
        }
    }

    fun onClearHistory() {
        _uiState.update { it.copy(history = emptyList()) }
    }

    fun copyToClipboard(text: String) {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Calculator Result", text)
        clipboard.setPrimaryClip(clip)
        _uiState.update { it.copy(snackbarMessage = "نتیجه کپی شد: $text") }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun isOperator(text: String): Boolean {
        return text in setOf("+", "-", "×", "÷", "^", "%")
    }

    private fun isLastCharOperator(expr: String): Boolean {
        if (expr.isEmpty()) return false
        val c = expr.last()
        return c in setOf('+', '-', '×', '÷', '^', '%', '(', '.')
    }

    private fun getLastNumberToken(expr: String): String {
        val sb = StringBuilder()
        for (i in expr.indices.reversed()) {
            val c = expr[i]
            if (c.isDigit() || c == '.') {
                sb.append(c)
            } else {
                break
            }
        }
        return sb.reverse().toString()
    }
}
