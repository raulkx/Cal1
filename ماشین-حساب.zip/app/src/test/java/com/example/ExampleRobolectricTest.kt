package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.calculator.CalculationResult
import com.example.calculator.CalculatorEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies Persian app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ماشین حساب", appName)
    }

    @Test
    fun `calculator engine basic operations`() {
        val resultAdd = CalculatorEngine.evaluate("15 + 27")
        assertTrue(resultAdd is CalculationResult.Success)
        assertEquals("42", (resultAdd as CalculationResult.Success).formatted)

        val resultSub = CalculatorEngine.evaluate("100 − 35")
        assertTrue(resultSub is CalculationResult.Success)
        assertEquals("65", (resultSub as CalculationResult.Success).formatted)

        val resultMul = CalculatorEngine.evaluate("12 × 8")
        assertTrue(resultMul is CalculationResult.Success)
        assertEquals("96", (resultMul as CalculationResult.Success).formatted)

        val resultDiv = CalculatorEngine.evaluate("100 ÷ 4")
        assertTrue(resultDiv is CalculationResult.Success)
        assertEquals("25", (resultDiv as CalculationResult.Success).formatted)
    }

    @Test
    fun `calculator engine operator precedence and parentheses`() {
        val precedence = CalculatorEngine.evaluate("2 + 3 × 4")
        assertTrue(precedence is CalculationResult.Success)
        assertEquals("14", (precedence as CalculationResult.Success).formatted)

        val withParens = CalculatorEngine.evaluate("(2 + 3) × 4")
        assertTrue(withParens is CalculationResult.Success)
        assertEquals("20", (withParens as CalculationResult.Success).formatted)
    }

    @Test
    fun `calculator engine scientific functions`() {
        val power = CalculatorEngine.evaluate("2 ^ 5")
        assertTrue(power is CalculationResult.Success)
        assertEquals("32", (power as CalculationResult.Success).formatted)

        val sqrt = CalculatorEngine.evaluate("√(144)")
        assertTrue(sqrt is CalculationResult.Success)
        assertEquals("12", (sqrt as CalculationResult.Success).formatted)

        val percent = CalculatorEngine.evaluate("50%")
        assertTrue(percent is CalculationResult.Success)
        assertEquals("0.5", (percent as CalculationResult.Success).formatted)
    }

    @Test
    fun `calculator engine handles divide by zero gracefully`() {
        val result = CalculatorEngine.evaluate("10 ÷ 0")
        assertTrue(result is CalculationResult.Error)
        assertEquals("تقسیم بر صفر ممکن نیست", (result as CalculationResult.Error).message)
    }

    @Test
    fun `calculator engine live preview`() {
        val previewIncomplete = CalculatorEngine.evaluatePreview("12 + ")
        assertEquals("12", previewIncomplete)

        val previewParens = CalculatorEngine.evaluatePreview("(5 × 3")
        assertEquals("15", previewParens)
    }

    @Test
    fun `persian digit conversion works bidirectionally`() {
        val western = "123,456.78"
        val persian = CalculatorEngine.toPersianDigits(western)
        assertEquals("۱۲۳٬۴۵۶٫۷۸", persian)

        val reversed = CalculatorEngine.fromPersianDigits(persian)
        assertEquals(western, reversed)
    }
}
